package Hola.maven.proyect.principal;

import static org.junit.jupiter.api.Assertions.*;

class HellowWorldTest {

}