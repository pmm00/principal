package Hola.maven.proyect.principal;

public class GreetingController {

}
